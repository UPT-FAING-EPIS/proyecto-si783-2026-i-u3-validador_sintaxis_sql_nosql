#!/usr/bin/env sh
set -eu
install -d /usr/local/bin /usr/local/lib/sqlcheck
install -m 0755 bin/sqlcheck /usr/local/bin/sqlcheck
cp -R lib/core /usr/local/lib/sqlcheck/core
install -m 0644 bin/local-skill.js /usr/local/bin/local-skill.js
echo "sqlcheck instalado. Prueba: sqlcheck --version"
